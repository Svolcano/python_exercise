__date__="Thu Apr 30 12:44:13 2015 +0800"
__version__="V2.0.0-1446-ge1a359d"
__email__="lixianzhi@gmail.com"
__author__="Xianzhi Li"
